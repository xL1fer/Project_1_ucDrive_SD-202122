              ________         __
 __ __   ____ \______ \_______|__|__  __ ____
|  |  \_/ ___\ |    |  \_  __ \  \  \/ // __ \
|  |  /\  \___ |    `   \  | \/  |\   /\  ___/
|____/  \___  >_______  /__|  |__| \_/  \___  >
            \/        \/                    \/

:: Considerações a ter em conta para executar as aplicações ::


> Os ficheiros .jar encontram-se dentro da pasta "jars".


> Para correr a aplicação Servidor, abrir a pasta "jars/UcDriveServer" e executar no terminal o comando "java -jar UcDriveServer.jar"
> Para correr o Servidor secundário, abrir a pasta "jars/UcDriveServerSecondary" e executar no terminal o comando "java -jar UcDriveServer.jar"

NOTA: nas configurações do servidor secundário é recomendada a utilização dos portos 7000 e 6000
	  para portos "my server" e "other server", respetivamente


> Para correr a aplicação Cliente, abrir a pasta "jars/Client" e executar no terminal o comando "java -jar Client.jar"